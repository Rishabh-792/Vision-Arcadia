# -*- coding: utf-8 -*-
"""
Created on Sat Sep 25 09:34:33 2021

@author: Rishabh
"""

import pandas as pd
import numpy as np
import os
import tensorflow as tf
import cv2
from tensorflow import keras
from  matplotlib import pyplot as plt
import matplotlib.image as mpimg
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Dense, Conv2D, MaxPooling2D, Flatten, Dropout, GlobalAveragePooling2D, Concatenate, Input
import random
from sklearn.model_selection import train_test_split

train = pd.read_csv("trainLabels.csv")
class_map = {
  "Fist" : 0,
  "Ok" : 1,
  "Swag" : 2,
  "Thumbs Down" : 3,
  "Thumbs Up" : 4,
  "Yo" : 5
}

def read_img(folder, df):
  X = []
  y = []
  for i in range(df.shape[0]):
    img = cv2.imread(folder + "/" + str(df.iloc[i, 0]) + ".jpg")
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    # img = cv2.resize(img, (32,32))       
    X.append(img)
    y.append(class_map[df.iloc[i, 1]])
  return np.array(X), np.array(y)

X, y = read_img('Gesture', train)
print(X.shape, y.shape)
x_train, x_f, y_train, y_f = train_test_split(X, y, test_size=0.2, shuffle=True)
x_test, x_val, y_test, y_val = train_test_split(x_f, y_f, test_size=0.5, shuffle=True)
print(x_train.shape, x_test.shape, y_train.shape, y_test.shape)

plt.imshow(x_train[random.randint(0, x_train.shape[0]-1)])
plt.show()

x_train = x_train/255.0
x_test = x_test/255.0
x_val = x_val/255.0

y_train = tf.one_hot(y_train.reshape(-1), 10)
y_test = tf.one_hot(y_test.reshape(-1), 10)
y_val = tf.one_hot(y_val.reshape(-1), 10)

model = Sequential(name="Numbers_Sequential_CNN")

model.add(Conv2D(64, (3, 3), activation='relu', input_shape=x_train.shape[1:]))
model.add(MaxPooling2D((2, 2)))
model.add(Conv2D(32, (3, 3), activation='relu'))
model.add(MaxPooling2D((2, 2)))
model.add(Conv2D(32, (3, 3), activation='relu'))
model.add(MaxPooling2D((2, 2)))

model.add(Flatten())

model.add(Dense(256, activation='relu'))
model.add(Dropout(0.15))
model.add(Dense(128, activation='relu'))
model.add(Dense(10, activation='softmax'))

model.compile(loss='categorical_crossentropy', optimizer="adam", metrics=['accuracy'])
print(model.summary())

print(model.fit(x=x_train, y=y_train, epochs=10, validation_data=(x_val, y_val)))

print(model.evaluate(x=x_test, y=y_test))

rand_idx = random.randint(0, x_test.shape[0]-1)
plt.imshow(x_test[rand_idx])
plt.show()

pred = model.predict(x_test[rand_idx].reshape(-1, *x_test[rand_idx].shape))

pred_cls = np.argmax(pred)
print(pred_cls)